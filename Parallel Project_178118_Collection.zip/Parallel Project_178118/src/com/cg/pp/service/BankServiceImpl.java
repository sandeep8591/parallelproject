package com.cg.pp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;
import com.cg.pp.dao.BankDao;
import com.cg.pp.dao.BankDaoImpl;
import com.cg.pp.exception.BankException;

public class BankServiceImpl implements BankService
{
	BankDao dao = new BankDaoImpl();
	
	Map<Integer,Customer> customer1 = new HashMap<Integer,Customer>();
	List<History> history1 = new ArrayList<History>();
	
	@Override
	public void createAccount(Customer customer) {
		
		dao.createAccount(customer);
	}

	@Override
	public void validateName(String customerName) throws BankException 
	{
		String customerNameRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerNameRegEx, customerName))
		{
			throw new BankException("Enter alphabets only.");
		}		
	}

	@Override
	public void validateAddress(String customerAddress) throws BankException 
	{		
		String customerAddressRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerAddressRegEx, customerAddress))
		{
			throw new BankException("Enter alphabets only.");
		}	
	}

	@Override
	public void validatePhone(String customerPhone) throws BankException 
	{
		String customerPhoneRegEx = "[7-9]{1}[0-9]{9}";
		if(!Pattern.matches(customerPhoneRegEx, customerPhone))
		{
			throw new BankException("Enter digits only.");
		}	
	}

	
	@Override
	public void validateAdhar(String customerAdhar) throws BankException 
	{
		String customerAdharRegEx = "[0-9]{12}";
		if(!Pattern.matches(customerAdharRegEx, customerAdhar))
		{
			throw new BankException("Enter digits only.");
		}	
		
	}

	@Override
	public void validateAmount(int amount) throws BankException 
	{
		String amountRegEx = "[0-9]+";
		if(!Pattern.matches(amountRegEx, String.valueOf(amount)))
		{
			throw new BankException("Enter digits only.");
		}	
	}

	@Override
	public void depositMoney(int cid, Double amount) 
	{
		dao.depositMoney(cid,amount);
		
	}

	@Override
	public double showBalance(int cust) 
	{
		return dao.showBalance(cust);
		
	}

	@Override
	public double withdrawMoney(int cid, double amount) {
		
		return dao.withdrawMoney(cid,amount);
	}

	@Override
	public void bankToWallet(int accountId, int amount1) 
	{
		dao.bankToWallet(accountId,amount1);
		
	}

	@Override
	public void walletToBank(int accountId, int amount1) {
		dao.walletToBank(accountId,amount1);
		
	}

	@Override
	public void walletToWallet(int accountId, int receiverId, int amount1) {
		dao.walletToWallet(accountId,receiverId,amount1);
		
	}

	@Override
	public double showWalletBalance(int cust) {
		
		return dao.showWalletBalance(cust);
	}

	@Override
	public List getHistory(int accountId) {
		// TODO Auto-generated method stub
		return dao.getHistory(accountId);
	}

	

	
	
	
	

}
