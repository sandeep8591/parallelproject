package com.cg.pp.bean;

public class Wallet {


	private int customerAccountNo;
	private double walletBalance;
	
	public int getCustomerAccountNo() {
		return customerAccountNo;
	}
	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}
	public double getWalletBalance() {
		return walletBalance;
	}
	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}
	@Override
	public String toString() {
		return "Wallet [customerAccountNo=" + customerAccountNo + ", walletBalance=" + walletBalance + "]";
	}
	public Wallet(int customerAccountNo, double walletBalance) {
		super();
		this.customerAccountNo = customerAccountNo;
		this.walletBalance = walletBalance;
	}
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
