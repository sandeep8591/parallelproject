package com.cg.pp.bean;

import java.time.LocalDateTime;

public class History 
{	private double customerBalance;
	private int customerAccountNo;
	private LocalDateTime depositDate;
	private String description;
	
	
	public History(double customerBalance, int customerAccountNo, LocalDateTime depositDate, String description) {
		super();
		this.customerBalance = customerBalance;
		this.customerAccountNo = customerAccountNo;
		this.depositDate = depositDate;
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}
	
	public int getCustomerAccountNo() {
		return customerAccountNo;
	}
	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}
	public LocalDateTime getDepositDate() {
		return depositDate;
	}
	public void setDepositDate(LocalDateTime depositDate) {
		this.depositDate = depositDate;
	}
	@Override
	public String toString() {
		return "History [customerBalance=" + customerBalance + ", customerAccountNo=" + customerAccountNo
				+ ", depositDate=" + depositDate + ", description=" + description + "]";
	}
	public History() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
