package com.cg.dao;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;
import com.cg.util.Collection;

public class CustomerBankDaoImp implements CustomerBankDao {
Collection col=new Collection();
	


	@Override
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException {
		BankAccount ba=col.getAccBalance(cusAccNumber);
		return ba;
	}



	@Override
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException {
		int ban=col.createAccount(bac,ca);
		return ban;
	}



	

}
