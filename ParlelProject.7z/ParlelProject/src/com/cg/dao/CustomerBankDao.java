package com.cg.dao;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;

public interface CustomerBankDao {
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException;
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException; 
	

}
