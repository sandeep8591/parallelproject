package com.cg.service;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;

public interface CustomerBankService {
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException;
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException;

}
