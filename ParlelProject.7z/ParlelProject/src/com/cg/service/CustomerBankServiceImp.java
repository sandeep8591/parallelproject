package com.cg.service;

import com.cg.dao.CustomerBankDaoImp;
import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;

public class CustomerBankServiceImp implements CustomerBankService {

	CustomerBankDaoImp cbdi=new CustomerBankDaoImp();

	@Override
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException {
	 BankAccount ba=cbdi.getAccBalance(cusAccNumber);
		return ba;
	}

	@Override
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException {
		int cs=cbdi.createAccount(bac,ca);
		return cs;
	}

	
}
